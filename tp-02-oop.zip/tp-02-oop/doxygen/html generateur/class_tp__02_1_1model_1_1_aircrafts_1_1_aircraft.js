var class_tp__02_1_1model_1_1_aircrafts_1_1_aircraft =
[
    [ "Aircraft", "class_tp__02_1_1model_1_1_aircrafts_1_1_aircraft.html#a53cfe8a117f922dbbcacd4248b5375fc", null ],
    [ "Capacity", "class_tp__02_1_1model_1_1_aircrafts_1_1_aircraft.html#a7661301b3eba54d7ce098a1d837acd91", null ],
    [ "Name", "class_tp__02_1_1model_1_1_aircrafts_1_1_aircraft.html#aeb9665d48b3c760e2bc6f4b490630fd3", null ]
];