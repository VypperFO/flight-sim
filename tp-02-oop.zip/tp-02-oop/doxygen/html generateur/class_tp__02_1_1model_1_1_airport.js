var class_tp__02_1_1model_1_1_airport =
[
    [ "Airport", "class_tp__02_1_1model_1_1_airport.html#ad24db9b29c38c64ad6f413c2d0f84d16", null ],
    [ "AircraftList", "class_tp__02_1_1model_1_1_airport.html#a436f137ef1890e7ad15534f00a0b7573", null ],
    [ "Coords", "class_tp__02_1_1model_1_1_airport.html#ad6e019514d3fba7bf93a3fd0f1c531c6", null ],
    [ "MaxMerchandise", "class_tp__02_1_1model_1_1_airport.html#ab2888d724168c3afe841b7719ee1b74e", null ],
    [ "MaxPassenger", "class_tp__02_1_1model_1_1_airport.html#a93c545233afadce4a0d7998d5bb8e011", null ],
    [ "MinMerchandise", "class_tp__02_1_1model_1_1_airport.html#ab1cece9b2407a2a6d9c8c95b6c7f391c", null ],
    [ "MinPassenger", "class_tp__02_1_1model_1_1_airport.html#ab83371bf51580f9cd3c3cbee20205a75", null ],
    [ "Name", "class_tp__02_1_1model_1_1_airport.html#a82d161b39540afb1a1ff0105eebbc9da", null ]
];