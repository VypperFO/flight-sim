var dir_fa4a390bdb215f013fe7ee2663e1a34a =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Tp-02.AssemblyInfo.cs", "_tp-02_8_assembly_info_8cs.html", null ],
    [ "Tp-02.GlobalUsings.g.cs", "_tp-02_8_global_usings_8g_8cs.html", null ]
];