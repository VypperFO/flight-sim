var searchData=
[
  ['_2enetcoreapp_2cversion_3dv6_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v6.0.AssemblyAttributes.cs',['../_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html',1,'']]]
];
