var searchData=
[
  ['dispose_0',['Dispose',['../class_tp__02_1_1_form_generator.html#a6aa42a8f5b8ce3f8a4c370e007f966b5',1,'Tp_02.FormGenerator.Dispose()'],['../class_tp__02_1_1view_1_1_form_map.html#a47cb801718df5d737299dd71137a5324',1,'Tp_02.view.FormMap.Dispose()']]]
];
