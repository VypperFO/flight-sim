var searchData=
[
  ['capacity_0',['Capacity',['../class_tp__02_1_1model_1_1_aircrafts_1_1_aircraft.html#a7661301b3eba54d7ce098a1d837acd91',1,'Tp_02::model::Aircrafts::Aircraft']]],
  ['coords_1',['Coords',['../class_tp__02_1_1model_1_1_airport.html#ad6e019514d3fba7bf93a3fd0f1c531c6',1,'Tp_02::model::Airport']]]
];
