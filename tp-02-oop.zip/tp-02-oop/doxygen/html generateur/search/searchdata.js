var indexSectionsWithContent =
{
  0: ".acdfghimnoprst",
  1: "acfghopst",
  2: "t",
  3: ".acfghoprst",
  4: "acdfghiost",
  5: "cfg",
  6: "acgmn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties"
};

