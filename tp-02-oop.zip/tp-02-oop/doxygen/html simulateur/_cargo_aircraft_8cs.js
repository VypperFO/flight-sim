var _cargo_aircraft_8cs =
[
    [ "Tp_02_02.model.Aircrafts.TransportAircrafts.CargoAircraft", "class_tp__02__02_1_1model_1_1_aircrafts_1_1_transport_aircrafts_1_1_cargo_aircraft.html", null ]
];