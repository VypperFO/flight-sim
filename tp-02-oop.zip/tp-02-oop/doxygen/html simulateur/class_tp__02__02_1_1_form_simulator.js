var class_tp__02__02_1_1_form_simulator =
[
    [ "FormSimulator", "class_tp__02__02_1_1_form_simulator.html#a21e429f0264f3c0b5d827278b0621022", null ],
    [ "clearAll", "class_tp__02__02_1_1_form_simulator.html#a66dd0b73e40e2805dd10051de04a1073", null ],
    [ "clearListboxes", "class_tp__02__02_1_1_form_simulator.html#a48b43a6f4b60edfdb2310bf71aeaece7", null ],
    [ "ConvertFromGPSToCoords", "class_tp__02__02_1_1_form_simulator.html#a48b64f00cbdd8dc858e836ab60aa5a90", null ],
    [ "Dispose", "class_tp__02__02_1_1_form_simulator.html#abf76472ddf737dc1f6ced8b691749df9", null ],
    [ "DrawLine", "class_tp__02__02_1_1_form_simulator.html#a710f6d6bd821f22ebf132ae92a62d5fe", null ],
    [ "getListbox1Selected", "class_tp__02__02_1_1_form_simulator.html#af6d61692f119223b2fadebd206a9a112", null ],
    [ "MovePlane", "class_tp__02__02_1_1_form_simulator.html#a7436870d3f179e74794db77d8fc24800", null ],
    [ "PlaceAirportsOnMap", "class_tp__02__02_1_1_form_simulator.html#a9c35820c24d57b8a0e473461d1c3fd3c", null ],
    [ "PlaceFire", "class_tp__02__02_1_1_form_simulator.html#ab7e3ca84b0da44fd88aaabac35d020f7", null ],
    [ "PlaceRescue", "class_tp__02__02_1_1_form_simulator.html#a10ada19c68bb7d1f24364107de2c548d", null ],
    [ "setAircrafts", "class_tp__02__02_1_1_form_simulator.html#a2c90ef6812afb545186a8fac6dcf78c6", null ],
    [ "setAirportsName", "class_tp__02__02_1_1_form_simulator.html#a9e27468407b95deee20c8638955ac418", null ],
    [ "setClients", "class_tp__02__02_1_1_form_simulator.html#a2d1316f22471a2592d841514165b3e06", null ],
    [ "SetPlayBtnEnable", "class_tp__02__02_1_1_form_simulator.html#a97a10600e731bafc94933a94defa54af", null ],
    [ "setTime", "class_tp__02__02_1_1_form_simulator.html#ad044d867b6a57d5094d20dcdf0563522", null ]
];