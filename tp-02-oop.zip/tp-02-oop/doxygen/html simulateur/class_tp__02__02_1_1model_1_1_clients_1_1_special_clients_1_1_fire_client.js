var class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_fire_client =
[
    [ "FireClient", "class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_fire_client.html#aa43d8eeca6eae0e40fbbf4bf3f1f9a13", null ],
    [ "Intensity", "class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_fire_client.html#a658fa5b2304595b8da3509d95be084f0", null ]
];