var class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_rescue_client =
[
    [ "RescueClient", "class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_rescue_client.html#afaf20e8a67c32e18c643ca6e57735bd9", null ]
];