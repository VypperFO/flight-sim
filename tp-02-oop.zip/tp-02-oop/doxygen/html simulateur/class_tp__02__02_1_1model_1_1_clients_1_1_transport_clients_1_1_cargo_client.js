var class_tp__02__02_1_1model_1_1_clients_1_1_transport_clients_1_1_cargo_client =
[
    [ "CargoClient", "class_tp__02__02_1_1model_1_1_clients_1_1_transport_clients_1_1_cargo_client.html#a8350210015533bdb5cffab0908d843c5", null ]
];