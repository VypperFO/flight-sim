var dir_319a1996b71dc35fe0eeff4e305d413d =
[
    [ "net6.0-windows", "dir_9147f35b121b3d15d962860cac3edc8f.html", "dir_9147f35b121b3d15d962860cac3edc8f" ]
];