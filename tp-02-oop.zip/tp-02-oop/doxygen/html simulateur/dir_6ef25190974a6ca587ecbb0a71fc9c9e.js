var dir_6ef25190974a6ca587ecbb0a71fc9c9e =
[
    [ "SpecialClients", "dir_87f568f8a6efad02445b833635cd6a87.html", "dir_87f568f8a6efad02445b833635cd6a87" ],
    [ "TransportClients", "dir_f72babc2a9df8ff615eacce9e25542ed.html", "dir_f72babc2a9df8ff615eacce9e25542ed" ],
    [ "Client.cs", "_client_8cs.html", "_client_8cs" ],
    [ "ClientFactory.cs", "_client_factory_8cs.html", "_client_factory_8cs" ]
];