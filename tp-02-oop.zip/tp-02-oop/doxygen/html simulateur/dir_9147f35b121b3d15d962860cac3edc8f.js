var dir_9147f35b121b3d15d962860cac3edc8f =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Tp-02-02.AssemblyInfo.cs", "_tp-02-02_8_assembly_info_8cs.html", null ],
    [ "Tp-02-02.GlobalUsings.g.cs", "_tp-02-02_8_global_usings_8g_8cs.html", null ]
];