var searchData=
[
  ['name_0',['Name',['../class_tp__02__02_1_1model_1_1_aircrafts_1_1_aircraft.html#af8925bd4cabc3154447c838208817653',1,'Tp_02_02.model.Aircrafts.Aircraft.Name()'],['../class_tp__02__02_1_1model_1_1_airport.html#a7e3ec28f7148151595c878b68554c068',1,'Tp_02_02.model.Airport.Name()']]],
  ['numberofclients_1',['NumberOfClients',['../class_tp__02__02_1_1model_1_1_clients_1_1_transport_clients_1_1_transport_client.html#a69263ca341055ddc97cdb21d004d4e07',1,'Tp_02_02::model::Clients::TransportClients::TransportClient']]]
];
