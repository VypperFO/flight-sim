var searchData=
[
  ['observeraircraft_0',['ObserverAircraft',['../class_tp__02__02_1_1model_1_1_aircrafts_1_1_special_aircrafts_1_1_observer_aircraft.html',1,'Tp_02_02::model::Aircrafts::SpecialAircrafts']]],
  ['observerclient_1',['ObserverClient',['../class_tp__02__02_1_1model_1_1_clients_1_1_special_clients_1_1_observer_client.html',1,'Tp_02_02::model::Clients::SpecialClients']]]
];
