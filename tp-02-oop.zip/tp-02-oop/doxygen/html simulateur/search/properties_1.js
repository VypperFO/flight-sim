var searchData=
[
  ['capacity_0',['Capacity',['../class_tp__02__02_1_1model_1_1_aircrafts_1_1_aircraft.html#ad882a1193f87d2ed993b9dfc1f733f7a',1,'Tp_02_02::model::Aircrafts::Aircraft']]],
  ['clientlist_1',['ClientList',['../class_tp__02__02_1_1model_1_1_airport.html#a338f720a7ff8615078bc91610cca1b1d',1,'Tp_02_02::model::Airport']]],
  ['coords_2',['Coords',['../class_tp__02__02_1_1model_1_1_airport.html#a81487b82e55c8c3636356ce8a178eddb',1,'Tp_02_02::model::Airport']]],
  ['currentposition_3',['CurrentPosition',['../class_tp__02__02_1_1model_1_1_aircrafts_1_1_aircraft.html#a6241c7a07c837349cac9c75dc9d29bc3',1,'Tp_02_02::model::Aircrafts::Aircraft']]]
];
